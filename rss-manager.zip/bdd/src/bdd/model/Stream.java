package bdd.model;

public class Stream {
    private String url;
    private String name;
    private String description;
    private String webLink;

    public String getUrl() {
	return url;
    }

    public void setUrl(String url) {
	this.url = url;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getDescription() {
	return description;
    }

    public void setDescription(String description) {
	this.description = description;
    }

    public String getWebLink() {
	return webLink;
    }

    public void setWebLink(String webLink) {
	this.webLink = webLink;
    }

    @Override
    public String toString() {

	return url;
    }

}
